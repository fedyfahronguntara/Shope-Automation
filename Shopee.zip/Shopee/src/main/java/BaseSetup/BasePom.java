package BaseSetup;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class BasePom {
        public static WebDriver driver;
        public BasePom(WebDriver driver) {
            this.driver = driver;
            PageFactory.initElements(driver, this);
        }
        protected static Helper.findElementHelper findElementHelper = new Helper.findElementHelper();
}
