package BaseSetup;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Setup {
        public static WebDriver driver=null;
        public void set_up()    {

            System.setProperty("webdriver.chrome.driver","Driver\\chromedriver.exe");
            driver = new ChromeDriver();
             driver.manage().window().maximize();
            driver.get("https://shopee.co.id/");
            driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

        }

        public void tearDown(){
            driver.quit();
        }

}
