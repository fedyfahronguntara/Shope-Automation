package Helper;

import BaseSetup.Setup;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

public class findElementHelper  extends Setup {
    public WebElement findElementByResourceXpath(String xpath) {
        WebElement element = null;
        System.out.println("Resource xpath :: " + xpath);
        try {
            element = driver.findElement(By.xpath(xpath));
        } catch (Exception e) {
            System.out.println("Error :: " + e.toString());
        }
        return element;
    }
    public void input(String xpath, String key) {
        WebElement element = findElementByResourceXpath(xpath);
        (element).clear();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        (element).sendKeys(key);
    }
    public void click(String xpath) {

        WebElement element = findElementByResourceXpath(xpath);
//        (new WebDriverWait(driver,30)).until(ExpectedConditions.visibilityOf(element));
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        (element).click();
    }

    public void getassert(String xpath,String text) {
        WebElement element = findElementByResourceXpath(xpath);
        (new WebDriverWait(driver,30)).until(ExpectedConditions.visibilityOf(element));
        try {
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            Assert.assertTrue((element).getText().contains(text));
        }catch (NoSuchElementException e) {
            Assert.fail("Elements " +(element)+" is not found");
        }
    }
}
