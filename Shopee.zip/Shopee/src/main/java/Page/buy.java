package Page;

import BaseSetup.BasePom;
import Helper.findElementHelper;
import org.openqa.selenium.WebDriver;

public class buy extends BasePom {

    public buy(WebDriver driver) {
        super(driver);
    }

    public void click_cross(){
        findElementHelper.click("//*[@id=\"main\"]/div/div[2]/div/div/shopee-banner-popup-stateful//div/div/div/div/div");
    }
    public void click_category(){
        findElementHelper.click("//*[@id=\"main\"]/div/div[2]/div/div/div[3]/div[2]/div[1]/div/div/div[2]/div/div[1]/ul/li[5]/div/a[1]/div");

    }
    public void click_product(){
        findElementHelper.click("//*[@id=\"main\"]/div/div[2]/div/div/div[4]/div[2]/div/div[2]/div[2]/a/div/div");
    }
    public void click_buybtn(){
        findElementHelper.click("//*[@id=\"main\"]/div/div[2]/div[1]/div/div[1]/div[2]/div[1]/div[3]/div/div[5]/div/div/button[2]");
    }

    public void asserloginpage(){
        findElementHelper.getassert("//*[@id=\"main\"]/div/div[2]/nav/div/div/div","Log in");
    }

}
