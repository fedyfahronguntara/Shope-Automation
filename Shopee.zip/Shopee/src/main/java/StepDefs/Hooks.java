package StepDefs;

import BaseSetup.Setup;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class Hooks extends Setup{
        @Before
        public void beforeScenario(Scenario scenario) {
            System.out.println("This will run before the Scenario");
            set_up();

        }

        @After
        public void afterScenario(Scenario scenario) {
            System.out.println("This will run after the Scenario");

        }
    }

