package StepDefs;

import BaseSetup.Setup;
import Page.buy;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebElement;

import java.util.concurrent.TimeUnit;

public class buydef extends Setup {
    buy page = new buy(driver);
    @Given("User go to shopee.co.id with non login state")
    public void userGoToShopeeCoIdWithNonLoginState() {
        System.out.println("userGoToShopeeCoIdWithNonLoginState");
        page.click_cross();
    }

    @When("choose category \\(the fifth category from latest) in category cell")
    public void chooseCategoryTheFifthCategoryFromLatestInCategoryCell() {
        page.click_category();
    }

    @When("choose number two product in product result \\(non promotion ads item)")
    public void chooseNumberProductInProductResultNonPromotionAdsItem() {
        page.click_product();
    }

    @When("click buy button in product detail page")
    public void clickBuyButtonInProductDetailPage() {
        page.click_buybtn();
    }

    @Then("User expect to see")
    public void userExpectToSee() {
        page.asserloginpage();
    }

}
